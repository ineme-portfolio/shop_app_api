<?php
require_once "config.php";

// Set the response content type to JSON
header("Content-Type: application/json");

$response = array();

// Create a new user
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $category = $_POST['category_id'];
    $category_name = $_POST['category_name'];

    $query = $db->prepare('INSERT INTO products (name, description, price, category_id, category_name) VALUES (:name, :description, :price, :category_id, :category_name)');
    $query->bindParam(':name', $name);
    $query->bindParam(':description', $description);
    $query->bindParam(':price', $price);
    $query->bindParam(':category_id', $category);
    $query->bindParam(':category_name', $category_name);
    $result = $query->execute();

    if($result){
        $response = ['success' => true, 'message' => 'Product Added successful!'];
        echo json_encode($response);
    }
}else{
    // Invalid API request
    $response = ['success' => false, 'message' => 'Invalid API request'];
    echo json_encode($response);
}