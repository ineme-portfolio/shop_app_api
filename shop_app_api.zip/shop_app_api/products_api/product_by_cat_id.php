<?php

// Connect to your database
require_once "config.php";

try {
  $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
} catch (PDOException $e) {
  die('Database connection failed: ' . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] === "GET") {
  $categoryId = $_GET["category_id"];
  $products = getProductsByCategoryId($categoryId);
  echo json_encode($products);
}

// Retrieve products by category ID
function getProductsByCategoryId($categoryId) {
  global $db;

  // Prepare the SQL query using JOIN and INNER JOIN
  $query = "SELECT p.*, c.category_name AS category_name 
            FROM products p
            INNER JOIN category c ON p.category_id = c.id
            WHERE p.category_id = :category_id";

  // Prepare the statement
  $statement = $db->prepare($query);

  // Bind the category ID parameter
  $statement->bindValue(':category_id', $categoryId, PDO::PARAM_INT);

  // Execute the query
  $statement->execute();

  // Fetch the results
  $results = $statement->fetchAll(PDO::FETCH_ASSOC);

  // Return the products list
  return $results;
}

?>
