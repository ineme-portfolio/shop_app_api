<?php
require_once "config.php";

// Set the response content type to JSON
header("Content-Type: application/json");

$response = array();

// Update a user by ID
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $category_id = $_POST['category_id'];

    $query = $db->prepare('UPDATE products SET name = :name, description = :description, price = :price, category_id = :category_id WHERE id = :id');
    $query->bindParam(':name', $name);
    $query->bindParam(':description', $description);
    $query->bindParam(':price', $price);
    $query->bindParam(':category_id', $category_id);
    $query->bindParam(':id', $id);
    $result = $query->execute();

    if($result){
        $response = ['success' => true, 'message' => 'Product Updated successful!'];
        echo json_encode($response);
    }
}else{
    // Invalid API request
    $response = ['success' => false, 'message' => 'Invalid API request'];
    echo json_encode($response);
}