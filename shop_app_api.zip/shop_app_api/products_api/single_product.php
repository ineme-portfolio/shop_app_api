<?php
require_once "config.php";

// Set the response content type to JSON
header("Content-Type: application/json");

// Retrieve a single user by ID
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];

    // using this method because we want to get the category name
    $query = $db->prepare("SELECT p.*, c.category_name AS category_name 
    FROM products p
    INNER JOIN category c ON p.category_id = c.id
    WHERE p.id = :id");

    //$query = $db->prepare('SELECT * FROM products WHERE id = :id');
    $query->bindParam(':id', $id);
    $query->execute();
    $product = $query->fetch(PDO::FETCH_ASSOC);
    echo json_encode($product);
}
