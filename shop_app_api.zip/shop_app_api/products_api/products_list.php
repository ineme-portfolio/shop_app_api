<?php
require_once "config.php";

// Set the response content type to JSON
header("Content-Type: application/json");

// Retrieve all users
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $query = $db->query('SELECT * FROM products');
    $response["details"] = array();
        
    while ($row = $query->fetch(PDO::FETCH_ASSOC)){
        $data = array();
        $data["id"]=$row["id"];
        $data["name"]=$row["name"];
        $data["description"]=$row["description"];
        $data["price"]=$row["price"];
        $data["category_id"]=$row["category_id"];
        array_push($response["details"], $data);
    }

    $response["success"] = true;
    $response["message"] = "Successfully Displayed";
    echo json_encode($response);

}else{
    // Invalid API request
    $response = ['success' => false, 'message' => 'Invalid API request'];
    echo json_encode($response);
}
