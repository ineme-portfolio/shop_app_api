<?php
require_once "config.php";

// Set the response content type to JSON
header("Content-Type: application/json");

// Delete a user by ID
if ($_SERVER['REQUEST_METHOD'] === 'DELETE' && isset($_GET['id'])) {

    $id = $_GET['id'];

    $query = $db->prepare('DELETE FROM products WHERE id = :id');
    $query->bindParam(':id', $id);
    $query->execute();

    echo json_encode(['message' => 'User deleted successfully']);
}else{
    // Invalid API request
    echo json_encode(['message' => 'Invalid API request']);
}