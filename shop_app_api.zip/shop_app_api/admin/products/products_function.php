<?php

// new product
if(isset($_POST["new_product"])){
    //Uploading to upload folder
  $target_dir = "uploads/";
  $basename = basename($_FILES["image"]["name"]);
  $upload_file = $target_dir.$basename;
  //move uploaded file
  $move = move_uploaded_file($_FILES["image"]["tmp_name"], $upload_file);
  if($move){
      $url = $upload_file;
      $title = $_POST["title"];
      $content = $_POST["content"];
      $price = $_POST["price"];
      $category_id = $_POST["category_id"];
      $image = $url;
      //SQL
      $sql = "INSERT INTO products(title, content, category_id, image, price) 
      VALUES('$title', '$content', '$category_id', '$image', '$price')";
      //Query
      $query = mysqli_query($connection, $sql);
      //Check if is stored
      if($query){
          //Success message
          $success = "Product published";
      }else{
          $error = "Unable to add product <br>".mysqli_error($connection);
      }
  }else{
      $error = "Unable to upload image";
  }
}

// edit product
if(isset($_POST["edit_product"])){
    $id = $_GET["edit_product_id"];
    //Update image
    if($_FILES["image"]["name"] != ""){
        //Uploading to upload folder
        $target_dir = "uploads/";
        $basename = basename($_FILES["image"]["name"]);
        $upload_file = $target_dir.$basename;
        //move uploaded file
        $move = move_uploaded_file($_FILES["image"]["tmp_name"], $upload_file);
        if($move){
            $url = $upload_file;
            $title = $_POST["title"];
            $content = $_POST["content"];
            $price = $_POST["price"];
            $category_id = $_POST["category_id"];
            $image = $url;
            //SQL
            $sql = "UPDATE products SET title = '$title', content = '$content', price = '$price', category_id = '$category_id', image = '$image' WHERE id = '$id'";
            //Query
            $query = mysqli_query($connection, $sql);
            //Check if is stored
            if($query){
                //Success message
                $success = "Product updated";
            }else{
                $error = "Unable to update product <br>".mysqli_error($connection);
            }
        }else{
            $error = "Unable to upload a new image";
        }
    }else{
        //Do not update image
        $title = $_POST["title"];
        $content = $_POST["content"];
        $price = $_POST["price"];
        $category_id = $_POST["category_id"];
        //SQL
        $sql = "UPDATE products SET title = '$title', content = '$content', price = '$price', category_id = '$category_id' WHERE id = '$id'";
        //Query
        $query = mysqli_query($connection, $sql);
        //Check if is stored
        if($query){
            //Success message
            $success = "Product updated";
        }else{
            $error = "Unable to update product <br>".mysqli_error($connection);
        }
    }
}

// delete product
 if(isset($_GET["delete_product"]) && !empty($_GET["delete_product"])){
    $id = $_GET["delete_product"];
    $sql = "DELETE FROM products WHERE id = '$id'";
    $query = mysqli_query($connection, $sql);
     //Check if is correct
    if($query){
        $success = "Product deleted successfully";
    }else{
        $error = "Unable to delete product";
    }
}
