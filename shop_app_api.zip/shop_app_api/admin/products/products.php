<?php
// session_start();
// if(!isset($_SESSION["user"])){
//     header("location: login.php");
// }

// if($_SESSION["user"]["role"] == "user"){
//     header("location: index.php");
// }
// //Script links
require "header.php"; 
?>
<div class="container">
    <?php
//For header content
//require './pages/header-home.php';
include "products_function.php";
?>
    <div class="container p-3">
        <div class="row">
            <div class="col-12">
                <div class="row">
                    <div class="col-6">
                        <h4>Welcome </h4>
                    </div>
                    <div class="col-6">
                        <a href="logout.php" class="btn btn-sm btn-danger">Logout</a>
                    </div>
                </div>
            </div>
            <div class="col-3">
                <h6>Navigations</h6>
                <ul>
                    <li>
                        <a href="posts.php">Posts</a>
                    </li>
                    <li>
                        <a href="comments.php">Comments</a>
                    </li>
                    <li>
                        <a href="new-post.php">Add New Post</a>
                    </li>
                    <li>
                        <a href="category.php">Categories</a>
                    </li>
                    <li>
                        <a href="users.php">Users</a>
                    </li>
                    <li>
                        <a href="new-user.php">Add New User</a>
                    </li>
                    <li>
                        <a href="products.php" class="text-danger">All Products</a>
                    </li>
                    <li>
                        <a href="new-product.php">New Product</a>
                    </li>
                </ul>
            </div>
            <div class="col-9">
                <div class="container">
                    <h6>All Products</h6>
                    <?php
                    if(isset($error)){
                        ?>
                    <div class="alert alert-danger">
                        <strong><?php echo $error; ?></strong>
                    </div>
                    <?php
                    }elseif(isset($success)){
                        ?>
                    <div class="alert alert-success">
                        <strong><?php echo $success; ?></strong>
                    </div>
                    <?php
                    }
                    ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Image</th>
                                <th scope="col">Title</th>
                                <th scope="col">Price</th>
                                <th scope="col">Date</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT * FROM products";
                            $query = mysqli_query($connection, $sql);
                            $count = 1;
                            while ($result = mysqli_fetch_assoc($query)) {
                                ?>
                            <tr>
                                <td scope="row"><?php echo $count; ?></td>
                                <td scope="row">
                                    <img height="50" src="<?php echo $result["image"] ?>"
                                        style="width: 50px;height: 50px;object-fit: cover;object-position: center;"
                                        alt="">
                                </td>
                                <td>
                                    <?php echo $result["title"] ?>
                                </td>
                                <td>
                                    <?php echo $result["price"] ?>
                                </td>
                                <td>
                                    <?php echo $result["timestamp"] ?>
                                </td>
                                <td>
                                    <a href="edit-product.php?edit_product_id=<?php echo $result["id"] ?>">Edit</a>
                                    |
                                    <a href="?delete_product=<?php echo $result["id"] ?>">Delete</a>
                                </td>
                            </tr>
                            <?php
                            $count++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">New Category</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" method="POST">
                        <div class="form-group">
                            <label for="">Title</label>
                            <input type="text" required name="name" placeholder="Enter title" class="form-control"
                                id="">
                        </div>
                        <div class="my-3">
                            <button type="submit" name="category" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <?php
//Footer content
//require './pages/footer-home.php';
//Footer script links
?>
</div>
<?php
require "footer.php";
?>