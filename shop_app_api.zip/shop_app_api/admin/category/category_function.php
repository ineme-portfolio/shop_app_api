<?php

// Add category
if(isset($_POST["category"])){
    $name = $_POST["name"];
    //SQL
    $sql = "INSERT INTO categories(name) VALUES('$name')";
    $query = mysqli_query($connection, $sql);
    if($query){
        $success = "Category added";
    }else{
        $error = "Unable to add category";
    }
}


// Delete category
if(isset($_GET["delete_category"]) && !empty($_GET["delete_category"])){
    $id = $_GET["delete_category"];
    //SQL
    $sql = "DELETE FROM categories WHERE id = '$id'";
    $query = mysqli_query($connection, $sql);
     if($query){
        $success = "Category deleted";
    }else{
        $error = "Unable to delete category";
    }
}

// Edit category
if(isset($_POST["edit_category"])){
    $name = $_POST["name"];
    $edit_id = $_GET["edit_id"];
    //SQL
    $sql = "UPDATE categories SET name = '$name' WHERE id = '$edit_id'";
    $query = mysqli_query($connection, $sql);
    if($query){
        $success = "Category updated";
    }else{
        $error = "Unable to update category";
    }
}
